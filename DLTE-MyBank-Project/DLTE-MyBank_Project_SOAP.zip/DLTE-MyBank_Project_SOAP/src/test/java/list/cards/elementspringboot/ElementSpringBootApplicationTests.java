package list.cards.elementspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElementSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
