package debit.cards.web.mybankdebitcard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DlteMyBankProjectWebServicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(DlteMyBankProjectWebServicesApplication.class, args);
    }

}
