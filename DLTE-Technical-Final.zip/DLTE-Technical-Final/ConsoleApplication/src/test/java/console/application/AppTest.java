//package console.application;
//
//import static org.junit.Assert.assertTrue;
//
//import backend.exceptions.ConnectionFailureException;
//import console.repository.EmployeeRepository;
//import console.services.EmployeeServices;
//import org.junit.Test;
//import static org.junit.Assert.*;
//import static org.mockito.Mockito.*;
//
//import java.io.ByteArrayInputStream;
//import java.io.InputStream;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.ResourceBundle;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.slf4j.Logger;
//
//import backend.method.EmployeeInterface;
//import console.application.App;
//import entity.console.Employee;
//import entity.console.EmployeeAddress;
//
//public class AppTest {
//
//    @Mock
//    private EmployeeRepository mockEmployeeRepository;
//
//    @Mock
//    private EmployeeServices employeeServices;
//
//    @Before
//    public void initialize() throws SQLException, ConnectionFailureException {
//        mockEmployeeInterface = new EmployeeServices();
//    }
//
//
//    @Test
//    public void testMain_Case1_Success() throws SQLException {
//        String input = "1\nJohn\nDoe\nSmith\n123\n9876543210\njohn.doe@example.com\nHouse1\nStreet1\nCity1\nState1\n123456\nHouse2\nStreet2\nCity2\nState2\n654321\nNo\n4\n";
//        InputStream in = new ByteArrayInputStream(input.getBytes());
//        System.setIn(in);
//
//        ResourceBundle mockResourceBundle = mock(ResourceBundle.class);
//        when(mockResourceBundle.getString(any(String.class))).thenReturn("");
//
//        App app = new App();
//        app.resourceBundle = mockResourceBundle;
//        app.logger = mockLogger;
//        app.validation = new Validation();
//
//        app.main(new String[] {});
//
//        // Verify that correct methods were called
//        verify(mockEmployeeInterface, times(1)).writeEmployeeDetails(any(Employee.class));
//    }
//
//    @Test
//    public void testMain_Case2_Success() throws SQLException {
//        String input = "2\n4\n";
//        InputStream in = new ByteArrayInputStream(input.getBytes());
//        System.setIn(in);
//
//        ResourceBundle mockResourceBundle = mock(ResourceBundle.class);
//        when(mockResourceBundle.getString(any(String.class))).thenReturn("");
//
//        List<Employee> mockEmployees = new ArrayList<>();
//        Employee mockEmployee = mock(Employee.class);
//        mockEmployees.add(mockEmployee);
//        when(mockEmployee.getFirstName()).thenReturn("John");
//        when(mockEmployee.getMiddleName()).thenReturn("Doe");
//        when(mockEmployee.getLastName()).thenReturn("Smith");
//        when(mockEmployee.getEmpID()).thenReturn(123);
//        when(mockEmployee.getMobileNumber()).thenReturn(9876543210L);
//        when(mockEmployee.getEmailID()).thenReturn("john.doe@example.com");
//        EmployeeAddress mockPermanentAddress = mock(EmployeeAddress.class);
//        when(mockEmployee.getPermanentAddress()).thenReturn(mockPermanentAddress);
//        when(mockPermanentAddress.getHouseName()).thenReturn("House1");
//        when(mockPermanentAddress.getStreetName()).thenReturn("Street1");
//        when(mockPermanentAddress.getCityName()).thenReturn("City1");
//        when(mockPermanentAddress.getStateName()).thenReturn("State1");
//        when(mockPermanentAddress.getPinCode()).thenReturn(123456);
//        EmployeeAddress mockTemporaryAddress = mock(EmployeeAddress.class);
//        when(mockEmployee.getTemporaryAddress()).thenReturn(mockTemporaryAddress);
//        when(mockTemporaryAddress.getHouseName()).thenReturn("House2");
//        when(mockTemporaryAddress.getStreetName()).thenReturn("Street2");
//        when(mockTemporaryAddress.getCityName()).thenReturn("City2");
//        when(mockTemporaryAddress.getStateName()).thenReturn("State2");
//        when(mockTemporaryAddress.getPinCode()).thenReturn(654321);
//
//        App app = new App();
//        app.resourceBundle = mockResourceBundle;
//        app.logger = mockLogger;
//        app.validation = new Validation();
//        app.employeeInterface = mockEmployeeInterface;
//
//        app.main(new String[] {});
//
//        // Verify that correct methods were called
//        verify(mockEmployeeInterface, times(1)).displayEmployeeDetails();
//    }
//
//    @Test
//    public void testMain_Case3_Success() throws SQLException {
//        String input = "3\n4\n";
//        InputStream in = new ByteArrayInputStream(input.getBytes());
//        System.setIn(in);
//
//        ResourceBundle mockResourceBundle = mock(ResourceBundle.class);
//        when(mockResourceBundle.getString(any(String.class))).thenReturn("");
//
//        App app = new App();
//        app.resourceBundle = mockResourceBundle;
//        app.logger = mockLogger;
//        app.validation = new Validation();
//        app.employeeInterface = mockEmployeeInterface;
//
//        app.main(new String[] {});
//
//        // Verify that correct methods were called
//        verify(mockEmployeeInterface, times(1)).getPermanentPinCodes();
//        verify(mockEmployeeInterface, times(1)).getTemporaryPinCodes();
//    }
//}
//
